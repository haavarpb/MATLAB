function showImage(I, t)
figure;
imshow(I, []);
title(t);
end