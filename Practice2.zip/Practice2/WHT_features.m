function [S] = WHT_features(I)

I = im2double(I);
% figure; imshow(I);
% title("Original image")

% Pre-processing 
[major, minor] = size(I);
cut =(major-minor)/2;
f = I(cut:(minor+cut-1),:);
% figure; imshow(f);

%% Divide the image in 8x8 blocks, each containing 50% of its neighbour

k = 1;
for i = 1:4:(minor-4)
    for j = 1:4:(minor-4)
        blocks(:,:,k)= f(i:(i+7),j:(j+7));
        k = k+1;
    end
end

%% Fast Walsh-Hadamard transform and coefficients mean for each block

[~,N,n] = size(blocks);
sum_c = zeros(1,n);
mean_c = zeros(1,n);

for k = 1:n
    C(:,:,k) = fwht(blocks(:,:,k));
    %C(:,:,k) = reshape(wht, [1, 484]);
    for i = 1:N
        for j = 1:N
%             if i==1 && j==1
%                 break
%             else
               sum_c(k) = sum_c(k) + C(i,j,k);
%             end
        end
    end
    mean_c(k) = sum_c(k)/(N^2-1);
end

%% Calculate the coefficients

S1 = zeros(1,n);
S2 = zeros(1,n);
S3 = zeros(1,n);
S4 = zeros(1,n);
S5 = zeros(1,n);

S1_sum = zeros(1,n);
S2_sum = zeros(1,n);
S3_sum = zeros(1,n);
S4_sum = zeros(1,n);
S5_sum = zeros(1,n);

for k = 1:n
    for i = 1:N
        for j = 1:N
%             if i==1 && j==1
%                 break
%             else
                S1_sum(k) = S1_sum(k)+(C(i,j,k)).^2;
                S2_sum(k) = S2_sum(k)+(abs(C(i,j,k)) - abs(mean_c(k)));
                S3_sum(k) = S3_sum(k) + (C(i,j,k) - mean_c(k))^2;
                S4_sum(k) = S4_sum(k) + abs(C(i,j,k));
                S5_sum(k) = S5_sum(k) + abs(C(i,j,k) - mean_c(k));
%             end
        end
    end
    S1(k) = S1_sum(k);
    S2(k) = S2_sum(k);
    S3(k) = S3_sum(k) / (N^2-1);
    S4(k) = S4_sum(k) / (N^2-1);
    S5(k) = S5_sum(k) / (N^2-1);
end

S1_n = (S1-min(S1))./(max(S1)-min(S1));
S2_n = (S2-min(S2))./(max(S2)-min(S2));
S3_n = (S3-min(S3))./(max(S3)-min(S3));
S4_n = (S4-min(S4))./(max(S4)-min(S4));
S5_n = (S5-min(S5))./(max(S5)-min(S5));

% S1_n = S1_n';
% S2_n = S2_n';
% S3_n = S3_n';
% S4_n = S4_n';
% S5_n = S5_n';


F1_n = reshape(S1_n,[22,22]);
F2_n = reshape(S2_n,[22,22]);
F3_n = reshape(S3_n,[22,22]);
F4_n = reshape(S4_n,[22,22]);
F5_n = reshape(S5_n,[22,22]);

F1_n = F1_n';
F2_n = F2_n';
F3_n = F3_n';
F4_n = F4_n';
F5_n = F5_n';


% figure; subplot(1,5,1); imshow(F1_n);
% subplot(1,5,2); imshow(F2_n);
% subplot(1,5,3); imshow(F3_n);
% subplot(1,5,4); imshow(F4_n);
% subplot(1,5,5); imshow(F5_n);

S = [S1_n, S2_n, S3_n, S4_n, S5_n];
% visualization = {F1_n, F2_n, F3_n, F4_n, F5_n}
end