%% Load Images
face_database = imageSet('att_faces','recursive');

%% Split Database into training and test sets
[training, test] = partition(face_database,[0.8 0.2]);

%% Extract WHT features for training set 
training_features = zeros(size(training,2)*training(1).Count,2420);
counter = 1;

for i=1:size(training,2)
    for j = 1:training(i).Count
        training_features(counter,:) = WHT_features(read(training(i),j));
        trainin_label{counter} = training(i).Description;    
        counter = counter + 1;
    end
    person_index{i} = training(i).Description;
end

%% Create classifier
face_classifier = fitcecoc(training_features,trainin_label);


